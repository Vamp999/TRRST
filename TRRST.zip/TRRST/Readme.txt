Extract to folder first before running.

Need Help dm me Vamp!#6666

